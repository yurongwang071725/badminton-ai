# 羽毛球动作智能化教学辅助系统

基于 MediaPipe 姿态估计与 DTW 动态时间规整算法的羽毛球击球动作实时诊断平台。

## 主要功能

- **六类动作识别**：高远球、杀球、吊球、挑球、搓球/放网、头顶球
- **六关节动力链分析**：踝 → 膝 → 髋 → 肩 → 肘 → 腕
- **双基准评价**：
  - 有标准模板：DTW 模板匹配（形状 35% + 幅度 65%）
  - 无标准模板：生物力学常模规则库
- **标准动作库**：支持标准视频分析保存或 CSV 角度数据导入

## 在线体验

部署在 [Streamlit Cloud](https://streamlit.io/cloud)。

## 本地运行

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 技术栈

- MediaPipe Pose
- OpenCV
- Streamlit
- NumPy / Pandas
- DTW

## 作者

同济大学运动训练专业 · 大学生创新创业训练项目
